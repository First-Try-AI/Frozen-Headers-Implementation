import SwiftUI

struct InputView: View {
    // 1. Accepts a function from the parent (ContentView)
    var onGenerate: (String) -> Void
    
    @State private var inputText: String = ""
    @FocusState private var isInputFocused: Bool
    
    // Limits
    let functionalLimit = 13000
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                
                // 1. CUSTOM APP TITLE BLOCK
                // Replaced hardcoded block with AppHeaderView
                AppHeaderView(isActive: !inputText.isEmpty)
                
                // 2. THE FORM
                Form {
                    Section {
                        ZStack(alignment: .topLeading) {
                            Color.clear
                                .frame(minHeight: 150, maxHeight: .infinity)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    isInputFocused = true
                                }
                            
                            TextField("Enter text to unlock knowledge...", text: $inputText, axis: .vertical)
                                .font(.body)
                                .focused($isInputFocused)
                                .frame(minHeight: 150)
                                .onChange(of: inputText) { _, newValue in
                                    if newValue.count > functionalLimit {
                                        inputText = String(newValue.prefix(functionalLimit))
                                    }
                                }
                        }
                        .listRowBackground(Color.black.opacity(0.2))
                        
                    } header: {
                        if inputText.isEmpty {
                            Text("Paste text.")
                                .foregroundColor(.white)
                                .opacity(0.75)
                        } else {
                            Button(action: {
                                onGenerate(inputText)
                            }) {
                                HStack(spacing: 6) {
                                    Text("Generate Audio")
                                        .fontWeight(.bold)
                                        .foregroundColor(Theme.accent)
                                    Image(systemName: "play.circle.fill")
                                        .foregroundColor(Theme.accent)
                                }
                                .padding(.vertical, 6)
                                .padding(.horizontal, 10)
                                .background(Color.black)
                                .cornerRadius(8)
                            }
                            .textCase(nil)
                            .font(.headline)
                        }
                    } footer: {
                        HStack {
                            Spacer()
                            Text("\(inputText.count) / \(functionalLimit)")
                                .foregroundColor(.gray)
                        }
                    }
                    
                    // REMOVED: Section with Big Generate Audio Button per requirements.
                }
                .scrollContentBackground(.hidden)
                .scrollDismissesKeyboard(.interactively)
            }
            .background(
                Image("AppBackground")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
            )
            .preferredColorScheme(.dark)
            .tint(Theme.accent)
            .toolbar(.hidden, for: .navigationBar)
            .onAppear {
                print("LOG: InputView appeared")
            }
        }
    }
}
