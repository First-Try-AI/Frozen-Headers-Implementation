import SwiftUI

struct AudioControlsView: View {
    @ObservedObject var sessionManager: SessionManager
    
    // We observe AudioService directly for button state to be reactive
    @ObservedObject private var audioService = AudioService.shared
    
    var body: some View {
        HStack(spacing: 20) {
            
            // Previous Button
            Button(action: {
                sessionManager.previousChunk()
            }) {
                Image(systemName: "backward.fill")
                    .font(.title2)
                    .foregroundColor(Theme.text.opacity(0.8))
                    .frame(width: 44, height: 44)
            }
            .disabled(sessionManager.currentChunkIndex == 0)
            .opacity(sessionManager.currentChunkIndex == 0 ? 0.3 : 1.0)
            
            // Play/Pause Button (Gold Gradient)
            Button(action: {
                sessionManager.togglePlayback()
            }) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: [Theme.accent, Theme.accentGoldEnd]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Theme.accentBorderGold, lineWidth: 2)
                    
                    HStack(spacing: 8) {
                        Image(systemName: audioService.isPlaying ? "pause.fill" : "play.fill")
                            .font(.headline)
                        Text(audioService.isPlaying ? "Pause" : "Play")
                            .fontWeight(.bold)
                    }
                    .foregroundColor(Theme.buttonText)
                }
                .frame(height: 50)
                // Expand horizontally but keep within reason
                .frame(maxWidth: 160)
            }
            
            // Next Button
            Button(action: {
                sessionManager.nextChunk()
            }) {
                Image(systemName: "forward.fill")
                    .font(.title2)
                    .foregroundColor(Theme.text.opacity(0.8))
                    .frame(width: 44, height: 44)
            }
            // Disable if at end
            .disabled(isAtEnd)
            .opacity(isAtEnd ? 0.3 : 1.0)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 30) // Safe area padding
        .padding(.top, 10)
        .background(Color.black.opacity(0.8).blur(radius: 10)) // Subtle background for controls
    }
    
    private var isAtEnd: Bool {
        guard let response = sessionManager.currentResponse else { return true }
        return sessionManager.currentChunkIndex >= (response.chunks.count - 1)
    }
}
